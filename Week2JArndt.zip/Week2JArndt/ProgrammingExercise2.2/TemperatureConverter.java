/** Program: Temperature Converter Program
 *File: TemperatureConverter.java
 * Summary: Converts Fahrenheit to Celsius and Celsius to Fahrenheit.
 * Author: Jacob Arndt
 * Date: 11/26/2017
 * */
package programmingExercise2;

import java.util.Scanner;

public class TemperatureConverter {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter a Fahrenheit temperature: ");
        double fahrenheit = input.nextDouble();

        double celsius = (5.0 / 9) * (fahrenheit - 32);
        System.out.println(fahrenheit + "F" + " is equivalent to " + celsius + "C");

        System.out.print("Enter a Celsius temperature: ");
        double Celsius = input.nextDouble();

        double Fahrenheit = 9 * (Celsius / 5) + 32;
        System.out.println(Celsius + "C" + " is equivalent to " + Fahrenheit + "F");

    }
}
