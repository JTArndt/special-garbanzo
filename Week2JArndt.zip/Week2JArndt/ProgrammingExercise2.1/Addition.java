/** Program: Addition Program
 * File: Addition: Addition.java
 * Summary: Finds the sum of five integers.
 * Author: Jacob Arndt
 * Date: 11/26/17
 * */
package programmingExercise2;

import java.util.Scanner;

public class Addition {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter a 5 digit integer: ");
        int number1 = input.nextInt();
        int number2 = input.nextInt();
        int number3 = input.nextInt();
        int number4 = input.nextInt();
        int number5 = input.nextInt();
        
        int sum = number1 + number2 + number3 + number4 + number5;

        System.out.println("The sum of the 5 integers is " + sum);
    
    }
}
